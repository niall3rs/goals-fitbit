### Goals

Fitbit Ionic app that can be used to track scorer and assister for goals while playing a game of football (or any sport that has the concept of goals, scoring and assisting).

Players are added via setting on the phone, and then goals can be added on the watch. The app supports up to 20 players and up to 20 goals. Goals can be deleted individually by selecting them from the goals list, or by deleting all from the home page.

### Credits

Icon made by Icon Pond from www.flaticon.com